<?php

namespace AdewaleAdeoye\LaravelGoogleSpreadsheet;

use Illuminate\Support\ServiceProvider;

class LaravelGoogleSpreadsheetServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap services.
     *
     * @return void
     */
    public function boot()
    {
        include __DIR__.'/routes/web.php';
    }

    /**
     * Register services.
     *
     * @return void
     */
    public function register()
    {
        $this->app->make('\AdewaleAdeoye\LaravelGoogleSpreadsheet\SheetController');
    }
}
