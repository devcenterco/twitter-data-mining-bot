<?php
namespace Adewaleadeoye\LaravelGoogleSpreadsheet;

require_once realpath(dirname(__FILE__) . '/google-api-php-client/vendor/autoload.php');
include_once "google-api-php-client/examples/templates/base.php";
$client = new Google_Client();

// class GoogleSheet 
// {
    

// }