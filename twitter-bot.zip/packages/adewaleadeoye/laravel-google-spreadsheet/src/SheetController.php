<?php

namespace AdewaleAdeoye\LaravelGoogleSpreadsheet;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
require_once __DIR__.('/google-api-php-client/vendor/autoload.php');
include_once __DIR__."/google-api-php-client/examples/templates/base.php";

dd(new Google_Client());

class SheetController extends Controller
{
    public function index(){
        
        //echo __DIR__;
    }
}
