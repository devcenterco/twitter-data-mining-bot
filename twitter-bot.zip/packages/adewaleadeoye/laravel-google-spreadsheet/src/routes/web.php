<?php
Route::get('sheet', '\AdewaleAdeoye\LaravelGoogleSpreadsheet\SheetController@index');